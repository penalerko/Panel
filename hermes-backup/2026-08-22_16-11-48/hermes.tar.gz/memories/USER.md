User communicates primarily in Persian (Farsi) with informal colloquial style via Telegram (DM with 𝒜𝓂𝒾𝓇 ℳ𝒾𝒶𝓈).
§
User is interested in Persian meme culture, especially Biggie Cheese / Barnyard mouse rapper Persian dub memes and similar viral content.
§
User expects meme searches to be verified for accuracy across multiple platforms: Google, YouTube, Aparat, Instagram, and Telegram channels (@persianmemes, @funnypersian, @iranianimemes). Accuracy is explicitly important.